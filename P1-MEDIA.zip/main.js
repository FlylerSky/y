alert('CHÀO MỪNG 🐜');
git remote add origin https: //github.com/FlylerSky/fly.git
  git branch - M main
git push - u origin main
